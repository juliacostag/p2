class Biblioteca {
    private Item[] itens;
    private int contador;

    public Biblioteca(int capacidade) {
        itens = new Item[capacidade]; // Cria um array com o tamanho da capacidade
        contador = 0; // Inicializa o contador em 0
    }

    public void adicionarItem(Item item) {
        if (contador < itens.length) { // Verifica se ainda há espaço no array
            itens[contador] = item; // Adiciona o item na posição do contador
            contador++; // Incrementa o contador
        } else {
            System.out.println("A biblioteca está cheia! Não é possível adicionar mais itens.");
        }
    }

    public void exibirItens() {
        System.out.println("Informações da Biblioteca:");
        for (int i = 0; i < contador; i++) {
            itens[i].exibirInformacoes();
        }
    }
}
