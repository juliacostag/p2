//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Biblioteca biblioteca = new Biblioteca(10); // Capacidade de 10 itens

        Livro livro1 = new Livro("O Senhor dos Anéis", "J.R.R. Tolkien", 1216);
        Revista revista1 = new Revista("Veja", "Editora Abril", 1234);

        biblioteca.adicionarItem(livro1); // Adiciona o primeiro livro
        biblioteca.adicionarItem(revista1);
        biblioteca.exibirItens();
    }
}