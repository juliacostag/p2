interface ItemBiblioteca {
    String getDescricao();
    void exibirInformacoes();
}