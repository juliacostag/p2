class Livro extends Item {
    private int numeroDePaginas;

    public Livro(String titulo, String autor, int numeroDePaginas) {
        super(titulo, autor);
        this.numeroDePaginas = numeroDePaginas;
    }

    public int getNumeroDePaginas() {
        return numeroDePaginas;
    }

    public void setNumeroDePaginas(int numeroDePaginas) {
        this.numeroDePaginas = numeroDePaginas;
    }

    @Override
    public String getDescricao() {
        return "Título: " + getTitulo() + ", Autor: " + getAutor() + ", Número de Páginas: " + numeroDePaginas;
    }

    @Override
    public void exibirInformacoes() {
        System.out.println(getDescricao());
    }
}
