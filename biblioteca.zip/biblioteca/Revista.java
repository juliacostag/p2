class Revista extends Item {
    private int numeroDaEdicao;

    public Revista(String titulo, String autor, int numeroDaEdicao) {
        super(titulo, autor);
        this.numeroDaEdicao = numeroDaEdicao;
    }

    public int getNumeroDaEdicao() {
        return numeroDaEdicao;
    }

    public void setNumeroDaEdicao(int numeroDaEdicao) {
        this.numeroDaEdicao = numeroDaEdicao;
    }

    @Override
    public String getDescricao() {
        return "Título: " + getTitulo() + ", Autor: " + getAutor() + ", Número da Edição: " + numeroDaEdicao;
    }

    @Override
    public void exibirInformacoes() {
        System.out.println(getDescricao());
    }
}